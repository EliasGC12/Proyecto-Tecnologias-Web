from django.db.models import *
from django.db import transaction
from app_escolar_api.serializers import UserSerializer
from app_escolar_api.serializers import *
from app_escolar_api.models import *
from rest_framework import permissions
from rest_framework import generics
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView   # <-- FALTABA ESTE IMPORT
from django.contrib.auth.models import Group
import json

class AlumnosAll(APIView):
    permission_classes = (permissions.IsAuthenticated,)

    def get(self, request, *args, **kwargs):
        alumnos= Alumnos.objects.filter(user__is_active=1)
        #este es el filtro
        buscar = request.GET.get("buscar")
        if buscar:
            alumnos = alumnos.filter(user__first_name__icontains=buscar)

        #Este es para el ordenamiento#
        ordenar = request.GET.get("ordenar")

        TRADUCCION = {
            "nombre_asc": "user_first_name",
            "nombre_desc": "-user_first_name",
            "matricula_asc": "matricula",
            "matricula_desc": "-matricula",
        }

        if ordenar in TRADUCCION:
            alumnos = alumnos.order_by(TRADUCCION[ordenar])
        else:
            alumnos = alumnos.order_by("id")

        
        lista = AlumnoSerializer(alumnos, many=True).data
        return Response(lista, 200)



class AlumnosView(generics.CreateAPIView):

    @transaction.atomic
    def post(self, request, *args, **kwargs):

        user = UserSerializer(data=request.data)
        if user.is_valid():
            role = request.data['rol']
            first_name = request.data['first_name']
            last_name = request.data['last_name']
            email = request.data['email']
            password = request.data['password']

            existing_user = User.objects.filter(email=email).first()
            if existing_user:
                return Response({"message": "Username "+email+" is already taken"}, 400)

            user = User.objects.create(
                username=email,
                email=email,
                first_name=first_name,
                last_name=last_name,
                is_active=1
            )
            user.set_password(password)
            user.save()

            group, created = Group.objects.get_or_create(name=role)
            group.user_set.add(user)

            alumno = Alumnos.objects.create(
                user=user,
                matricula=request.data["matricula"],
                curp=request.data["curp"].upper(),
                rfc=request.data["rfc"].upper(),
                fecha_nacimiento=request.data["fecha_nacimiento"],
                edad=request.data["edad"],
                telefono=request.data["telefono"],
                ocupacion=request.data["ocupacion"]
            )

            return Response({"Alumno creado con ID: ": alumno.id}, 201)

        return Response(user.errors, status=status.HTTP_400_BAD_REQUEST)