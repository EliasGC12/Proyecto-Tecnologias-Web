# app_escolar_api/urls.py - CONTENIDO CORREGIDO
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.http import HttpResponse
from app_escolar_api.views import users, alumnos, maestros, auth

print("✅ app_escolar_api/urls.py se está cargando correctamente")

urlpatterns = [
    # Create Admin
    path('admin/', users.AdminView.as_view()),
    # Admin Data
    path('lista-admins/', users.AdminAll.as_view()),
    # Create Alumno
    path('alumnos/', alumnos.AlumnosView.as_view()),
    # Create Maestro
    path('maestros/', maestros.MaestrosView.as_view()),
    # Listar alumnos - ¡ESTA ES LA LÍNEA CLAVE!
    path('lista-alumnos/', alumnos.AlumnosAll.as_view()),
    # Listar maestros
    path('lista-maestros/', maestros.MaestrosAll.as_view()),
    # Login
    path('login/', auth.CustomAuthToken.as_view()),
    # Logout
    path('logout/', auth.Logout.as_view()),
    # Ruta de prueba
    path('test-simple/', lambda request: HttpResponse("✅ Ruta simple funciona")),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

print("✅ URLs configuradas:", [str(p.pattern) for p in urlpatterns])